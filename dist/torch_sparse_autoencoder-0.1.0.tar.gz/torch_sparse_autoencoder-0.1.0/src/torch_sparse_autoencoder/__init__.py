# Content of __init__.py:
from .core import SparseAutoencoderManager

__version__ = "0.1.0"
__all__ = ["SparseAutoencoderManager"]
